# rocket-trajectory-optimizer

Physics-based rocket ascent simulation and pitch-angle optimization using Python, SciPy ODE solvers, and numerical methods for trajectory analysis.

## Run
```
pip install -r requirements.txt
python main.py
```
Plots will be saved to the plots folder.
